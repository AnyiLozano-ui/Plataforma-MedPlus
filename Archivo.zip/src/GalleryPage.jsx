// src/GalleryPage.jsx
import React, { useState } from 'react'

const PHOTOS_PER_PAGE = 8
const TOTAL_PAGES = 118

// Simulación de muchas fotos (luego las cambias por tus URLs reales)
const allPhotos = Array.from(
  { length: PHOTOS_PER_PAGE * TOTAL_PAGES },
  (_, i) => ({
    id: i + 1,
    // Cambia esto por la ruta real de tus fotos
    src: `https://picsum.photos/seed/nc-${i + 1}/600/800`,
  })
)

export default function GalleryPage() {
  const [page, setPage] = useState(1)
  const [selected, setSelected] = useState(() => new Set())

  const startIndex = (page - 1) * PHOTOS_PER_PAGE
  const pagePhotos = allPhotos.slice(startIndex, startIndex + PHOTOS_PER_PAGE)

  const toggleSelected = (id) => {
    setSelected((prev) => {
      const copy = new Set(prev)
      if (copy.has(id)) copy.delete(id)
      else copy.add(id)
      return copy
    })
  }

  const goToPage = (newPage) => {
    if (newPage < 1 || newPage > TOTAL_PAGES) return
    setPage(newPage)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <div className="min-h-screen bg-[#f4f4f4] flex flex-col">
      {/* HEADER AMARILLO */}
      <header className="w-full bg-[#ffd438] shadow-md">
        <div className="max-w-6xl mx-auto h-20 px-6 flex items-center gap-4">
          <div className="w-11 h-11 rounded-md bg-black flex items-center justify-center">
            <span className="text-xl text-[#ffd438] font-bold">🔥</span>
          </div>
          <span className="text-lg font-semibold text-black tracking-wide">
            TNC
          </span>
        </div>
      </header>

      {/* CONTENIDO PRINCIPAL */}
      <main className="flex-1">
        <div className="max-w-6xl mx-auto my-10 bg-white rounded-md shadow-sm border border-slate-200">
          {/* GRID DE FOTOS */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 p-6">
            {pagePhotos.map((photo) => (
              <div
                key={photo.id}
                className="bg-white rounded-md shadow-sm border border-slate-200 overflow-hidden flex flex-col"
              >
                {/* IMAGEN */}
                <div className="relative">
                  {/* Aspect ratio vertical tipo tarjeta */}
                  <div className="pt-[135%] bg-slate-200">
                    <img
                      src={photo.src}
                      alt={`Foto ${photo.id}`}
                      className="absolute inset-0 w-full h-full object-cover"
                    />
                  </div>

                  {/* CHECK DE SELECCIÓN */}
                  <button
                    type="button"
                    onClick={() => toggleSelected(photo.id)}
                    className={`absolute top-2 right-2 w-7 h-7 rounded-full border flex items-center justify-center text-xs font-semibold
                      ${
                        selected.has(photo.id)
                          ? 'bg-[#1f3c63] border-[#1f3c63] text-white'
                          : 'bg-white/95 border-slate-300 text-slate-500'
                      }`}
                  >
                    ✓
                  </button>
                </div>

                {/* BOTÓN DOWNLOAD */}
                <button
                  type="button"
                  className="mt-auto flex items-center justify-center gap-2 bg-[#102845] text-[11px] font-semibold tracking-wide text-white uppercase py-2 hover:bg-[#1a3557] transition"
                  onClick={() => {
                    // Aquí cambias por la lógica real de descarga
                    window.open(photo.src, '_blank')
                  }}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="w-4 h-4"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path d="M9 2a1 1 0 012 0v8.586l2.293-2.293a1 1 0 111.414 1.414l-4.0 4a1 1 0 01-1.414 0l-4.0-4A1 1 0 115.707 8.293L8 10.586V2z" />
                    <path d="M4 14a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1z" />
                  </svg>
                  DOWNLOAD
                </button>
              </div>
            ))}
          </div>

          {/* PAGINACIÓN */}
          <div className="border-t border-slate-200 px-4 py-4 flex flex-col items-center gap-3">
            {/* Botones de página (1 2 3 4 5 ... >) */}
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => goToPage(n)}
                  className={`min-w-[2.2rem] h-8 border text-sm rounded-sm px-2
                    ${
                      page === n
                        ? 'bg-[#1f3c63] text-white border-[#1f3c63]'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                    }`}
                >
                  {n}
                </button>
              ))}

              <span className="px-2 text-xs text-slate-500">…</span>

              <button
                type="button"
                onClick={() => goToPage(page + 1)}
                disabled={page === TOTAL_PAGES}
                className={`min-w-[2.2rem] h-8 border text-sm rounded-sm px-2 flex items-center justify-center
                  ${
                    page === TOTAL_PAGES
                      ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-default'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                  }`}
              >
                &gt;
              </button>
            </div>

            {/* Texto "Página X de Y" */}
            <p className="text-[11px] text-slate-500">
              Página <span className="font-semibold">{page}</span> de{' '}
              <span className="font-semibold">{TOTAL_PAGES}</span>
            </p>
          </div>
        </div>

        {/* FOOTER AMARILLO (igual que la franja de arriba) */}
        <div className="w-full bg-[#ffd438] h-24 mt-10" />
      </main>
    </div>
  )
}
